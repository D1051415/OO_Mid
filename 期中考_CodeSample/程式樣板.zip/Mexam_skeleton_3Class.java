import java.math.BigInteger;

public class Mexam_skeleton_3Class extends BigInteger{

	public Mexam_skeleton_3Class(String val) {
		// TODO: Add some code here
	}
	
	public Mexam_skeleton_3Class add(Mexam_skeleton_3Class val) {
		// TODO: Add some code here
	}
	
	public Mexam_skeleton_3Class add(BigInteger val) {
		// TODO: Add some code here
	}
	
	public Mexam_skeleton_3Class subtract(Mexam_skeleton_3Class val) {
		// TODO: Add some code here
	}
	
	public Mexam_skeleton_3Class subtract(BigInteger val) {
		// TODO: Add some code here
	}
	

	public String toString() {
		// TODO: Add some code here
	}
}
