import java.util.Arrays;

public class Mexam_skeleton_4APP {

	public static void main(String [] args){
		
		// TODO: Add some code here for input testing data
		Mexam_skeleton_4Class[] scoreArray = new Mexam_skeleton_4Class[???];
		
		// TODO: Add some code here for sorting the array

		
		// TODO: Add some code here for output the result
	
	}


}
