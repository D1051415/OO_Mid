public class Mexam_skeleton_4Class implements ???? {
	
	public type swimingScore;
	public type bikingScore;
	public type runningScore;

	public Score() {
		// TODO: Add some code here
	}
	
	public Score(type swimingScore, type bikingScore, type runningScore) {
		// TODO: Add some code here
	}
	
	public int compareTo(Score o)
	{
		// TODO: Add some code here  & return value
	}
}
